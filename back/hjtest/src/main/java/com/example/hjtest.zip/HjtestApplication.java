package com.example.hjtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HjtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HjtestApplication.class, args);
	}

}
