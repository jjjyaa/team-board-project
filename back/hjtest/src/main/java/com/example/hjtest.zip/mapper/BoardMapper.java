//package com.example.hjtest.mapper;
//
//import com.example.hjtest.Dto.BoardDto;
//import org.apache.ibatis.annotations.Mapper;
//import java.util.List;
//
//@Mapper
//public interface BoardMapper {
//    List<BoardDto> searchBoards(String searchType, String searchTerm);
//}
